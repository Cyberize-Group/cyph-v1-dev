# QAM_EXECUTION_REPORT — `APBM-003-CYBER-PHARMA` (Q2 attempt 01)

> Instantiated 2026-11-05 by Friday from TEMPLATE SET v0.3 (QA Lead accepted 2026-10-14) under QAM_PLAYBOOK v1.0. **Owner: QA Executor (Claudy).** Measurements, attempts, stops, helper corrections, limitations. **No self-certification.**

**Executor:** Claudy / Claude Code (Fable 5.1) · **Start:** 2026-11-09 09:15 +06 (entry check), 09:25 (T-00) · **End:** 2026-11-09 10:45 +06 · **Working directory:** `/home/moose/NEXTJS/CYBER_PHARMA/cyph-v1-dev` (repo root, branch `qa/apbm-003`); product commands (`npm ci`, `next build`, Jest, harness, seed, runner) executed in a QA copy of HEAD's tracked tree made with `git archive HEAD` at `/tmp/claude-1000/…/scratchpad/qa-tree` (byte-identical product; empty `.env.local`; no secret copied) so Cody's `:3137` standalone server under the repo's `.next/` was never disturbed. Helper evidence written into the copy's `QAM/evidence/<lane>` was copied back verbatim.

## 1. Entry verification
| Check | Value | Evidence |
|---|---|---|
| Approved plan SHA-256 = `QAM_APPROVAL.md` §2 | `194538a7a7701c4b35aa731b17197f4e6ddb577d43ce4f7ac8bbdb383a5cfea4` — MATCH (bound by Friday 2026-11-07 17:00 +06) | `evidence/identity/02/t00_repin.txt` |
| Current full HEAD on `qa/apbm-003` | `4d64504e85c56f1c987a703dd94575f489cb99ce` ("APBM-003 QA: record release commit SHA") | same |
| Candidate = approved candidate | `308247a24e6ddd455842da5cd2e21541d7eae2c1`; ancestor of HEAD (`merge-base --is-ancestor` exit 0); the 3 commits above it (`051344c`, `189df31`, `4d64504`) touch only `agent_docs/` | same; `git diff 308247a HEAD -- . :(exclude)agent_docs` = 0 lines |
| Targets = approved targets | SCRATCH `ihgcsrypblqkwommrkgj` (URL-side ref + SQL-side "DEV fingerprint absent" fence before every destructive step); DEV `yrsuwikjnbmvpznrgydb` (URL-side ref + SQL-side 7-cast-uid fingerprint, READ ONLY, ROLLBACK, statement filter); LOCAL `127.0.0.1:3138`; STAGING none | `evidence/identity/02/{scratch_shim_fence_attack.txt,ro_sql_fence_attacks.txt}` (both fences attacked once: wrong ref → refused, nothing run) |
| Director release present | `QAM_APPROVAL.md` §3 (Tony, 2026-11-09, commit `189df312…`): Q2 released; R-10 SCRATCH destruction authorized; SCRATCH signup posture UNKNOWN → AC-404 SCRATCH half BLOCKED; `APBM_RULINGS.md` C-01/C-02 present; `QAM_STATE.md` = `RELEASED FOR Q2`; `.env.qa.local` RESULT PASS 21/21 mode 0600 | `evidence/identity/02/t00_repin.txt` |
| Candidate → HEAD classification (complete diff) | 48 paths, all `agent_docs/**` (QAM records, Q1/Q1b packages, RESPONSES, SESSIONS, APBM_RULINGS §C); product content 0 lines | `evidence/identity/02/t00_repin.txt` |
| **Q4 only:** repaired candidate … | n/a | |
| Changeable readiness rows rechecked | PF-1.2, 1.3, 1.6, 3.2, 4.1, 4.2, 4.4, 4.6, 4.7, 5.1 (+5.2, 5.3) recorded in `QAM_PREFLIGHT.md` Result/Evidence cells as "Q2"; PF-1.3 remains FAIL (inherited, 69→71 dirty paths, all `agent_docs/`, none product); PF-4.7 PARTIAL (DEV PASS, SCRATCH BLOCKED) | `QAM_PREFLIGHT.md`; `evidence/identity/02/{git_status_porcelain_q2_start.txt,dirty_diff_vs_q1.txt}` |
| Q1 instrument evidence reused / setup repeated | Q1 `identity/01` reused as the baseline for the dirty-state diff and the lockfile/package.json diffs (re-run in Q2 anyway); everything else executed fresh in Q2 | `evidence/identity/02/` |

Derivation artifacts (AM-1/AM-2) were written **before** any graded test: `evidence/derivations/01/{board.md,policies.md,catalog_counts.md,seed_audit.md,cast.md,money_rules.md,ui_dispatch_counts.md,allowlist.md,allowlist.json,matrix_delta.md}` (09:27–09:29 +06; T-01 started 09:35, Group B 09:35, Group C 09:51).

## 2. Execution log (plan order)
| Test ID | AC(s) | Command / steps (working dir) | Started | Result | Evidence path | Note |
|---|---|---|---|---|---|---|
| T-00 | all | PF-1.x re-run; `git diff 308247a HEAD`; dirty-state diff vs Q1; plan hash; §2/§3/§C/state/env on disk (repo root) | 09:25 | PASS | `evidence/identity/02/t00_repin.txt` | HEAD ≠ candidate SHA but product content identical; dispatch `RELEASED FOR Q2` satisfied |
| T-01 | AC-803 | `npm ci` (QA tree) · `next build` real mode via `AUTOMATION/launch-dev-real.mjs` · `npx tsc --noEmit` · `npx eslint .` · `NEXT_PUBLIC_APBM_DATA_MODE=mock npx jest --runInBand --ci` | 09:33–09:41 | PASS | `evidence/board/01/*` | ci exit 0 (854 pkgs, lockfile sha unchanged); build exit 0; tsc 0 errors; lint 0 errors / 34 warnings; Jest 39 suites / 196 tests, 0 skipped, 0 failed; controls: broken scratch test fails, skip-grep 0 |
| T-02 | AC-804 | `git diff af2c7e5..308247a -- package-lock.json` / `package.json` | 09:37 | PASS | `evidence/identity/02/{lockfile_diff.txt,package_json_diff.txt,t02_dependencies.txt}` | lockfile 0 lines; scripts-only; control diff 13 560 lines on a known lockfile commit |
| T-03 | AC-301, AC-501 | grep over `src/**` + classification; service greps | 09:33 | PASS | `evidence/reads/01/grep_user_data.txt` | 0 direct reads; baseline control assumption wrong (0 hits at `af2c7e5`) → pattern proven on a known positive (F-07f) |
| T-04 | AC-502 | allowlist comparison (`allowlist.json`) of 56 product paths | 09:33 | PASS | `evidence/identity/02/allowlist_check.json` | 0 outside; protected untouched; fake path flagged |
| T-05 | AC-506, AC-107 | auth-path diffs; route find; `user_roles` grep | 09:33 | PASS | `evidence/identity/02/t05_auth_routes.txt` | control diff 439 lines across the auth path's own history |
| T-06 | AC-101 | migrations 0001–0047 diff | 09:33 | PASS | `evidence/identity/02/t06_migrations_0001_0047.txt` | 0 lines |
| T-07 | AC-206 | generator source review + planted-reference control | 09:33 | PASS | `evidence/seed/01/generator_review.md` | |
| T-08 | AC-205 | `AUTOMATION/money-rules.mjs --mocks` on candidate and baseline fixtures | 09:37 | PASS | `evidence/seed/01/{mocks_money_rules.json,mocks_money_rules_baseline_control.json}` | 0/50 vs baseline 150/150 failures |
| T-09 | AC-801 (part) | harness diff review + flips derivation | 09:33 | PASS | `evidence/regression/01/{harness_diff_review.md,harness_diff.patch}`; `derivations/01/matrix_delta.md` | 13 flips exactly; the single `15` hit is a timestamp slice |
| T-10 | AC-101 | shim → `apply-forward inventory` · `scratch-reset` · `dev-verify` · `apply` ×2 · tamper A/B (copy) · restore · `scratch-reset --through 47` · control query · `apply` (0048–0052) · `dev-verify` · `apply` (no-op) | 09:35, 09:45 | PASS | `evidence/schema/01/*` | 52 committed; no-ops 0; both tampers refused; forward 5 committed; catalog `66782ff9…` |
| T-11 | AC-102, 103, 106, 107, 405 | `AUTOMATION/t11_catalog.sql` via `scratch-sql.mjs` (rollback); 0047 control; no-account probe | 09:46, 10:40 | PASS | `evidence/schema/01/{catalog.json,catalog_control_at_47.json,no_account_no_junction.json}` | 15 policies, 0 on `user_data`; grants observation → F-02 |
| T-12 | AC-201 | `seed:reset` · `seed:run` (private /tmp cast file) · `seed:verify` · QA hash · reset · run · `verify --compare` · QA hash · poison/revert/touch | 09:50–09:52 | PASS | `evidence/seed/01/*` | hashes equal; attack detected by both comparators |
| T-13 | AC-202 | `seed:scan`; poison stored columns; `seed:verify`; revert; `verify --compare` | 09:52, 10:02 | PASS | `evidence/privacy/01/*` | first poison used a non-existent column (HC-2) |
| T-14 | AC-203 | cast SQL inside `cast-matrix.mjs` | 09:52, 10:02 | PASS | `evidence/seed/01/cast.json` | first run counted all `auth.users` (HC-3) |
| T-15 | AC-204 | `money-rules.mjs --scratch`; poison; `seed:verify`; revert | 09:52, 10:01 | PASS | `evidence/seed/01/money_rules_*.json` | first run 130 false failures from a DATE typing bug (HC-1) |
| T-16 | AC-207 | audit counts before/after each run/reset; attribution; by-table; intact check; source grep | 09:50–10:03 | PASS | `evidence/audit/01/seed_audit.json` | reset adds 285 `delete` stamps (F-07e) |
| T-17 | AC-302, 104, 102 | `cast-matrix.mjs` (7 real logins, publishable key) | 09:52, 10:02 | PASS | `evidence/audit/01/{direct_denials.json,cast_matrix.log}` | 172 PASS / 1 FAIL where the FAIL is the TRUNCATE **observation** probe (F-02); `--attack-flip` run FAILs as required |
| T-18 | AC-303 | in `cast-matrix.mjs` | 10:02 | PASS | `evidence/audit/01/owner_reach.json` | |
| T-19 | AC-305, 603 | in `cast-matrix.mjs` + T-11 shape rows | 10:02 | PASS | `evidence/audit/01/admin_rpcs.json` | |
| T-20 | AC-304 (SQL level) | in `cast-matrix.mjs` | 10:02 | PASS | `evidence/audit/01/operation_counts.json` | retry 2, rejected 0 |
| T-21 | AC-105 | `AUTOMATION/t21-trigger.mjs` (secret key, SCRATCH) | 09:52 | PASS | `evidence/schema/01/trigger.json` | probe deleted |
| T-22 | AC-106 | SQL via `scratch-sql.mjs --continue-on-error` (rolled back) | 09:52, 09:57 | PASS | `evidence/schema/01/one_admin.json` | first run lacked savepoints (HC-7) |
| T-23 | AC-801 | shim → `npm run rls:prove -- APBM_QA`; corrupted-expectation harness run (copy); `npm run audit:prove` | 10:03–10:07 | PASS | `evidence/regression/01/*` | 320 cells GREEN, 15 observed policies, 28 attacks; corruption → RED exit 3; audit:prove 8/8 |
| T-24 | AC-802 | shim → `db-verify.mjs`, `--probes` | 10:07 | PASS | `evidence/regression/01/db_verify*.log` | ALL GREEN ×2 |
| T-30 | AC-401, 402, 403, 405 | `AUTOMATION/dev-apply-check.mjs` (every statement through `ro-sql.sh`) | 09:39–09:44 | PASS (AC-401 restore clause = ACCEPTED LIMITATION) | `evidence/apply/01/*` | first runs: json_agg line-wrap and privilege-word filter corrections (HC-8, HC-9) |
| T-31 | AC-404, 405 | same + `GET /auth/v1/settings` (apikey only) | 09:39 | PARTIAL: a/b/c PASS, d BLOCKED | `evidence/apply/01/signup_settings.json` | SCRATCH half BLOCKED — owner Director |
| T-32 | AC-501, MR-14 | real-mode build (QA tree) + serve `:3138` + bundle scan (+ fixture control) | 09:35, 09:51 | PASS | `evidence/deploy/01/{BUILD.json,build.log,bundle_scan.json,server.log}` | 0 SCRATCH refs, 7 DEV refs, 0 secret patterns |
| T-33 | AC-503, 504, 601, 603 | `AUTOMATION/role-matrix.mjs --phase matrix` (7 identities; rerun for MEMBER_B1/UNRELATED after HC-4) | 09:57, 10:05, 10:22 | PASS | `evidence/browser/01/{matrix*.json,*.log,shots/,har/}` | run 2: 109/111 (2 instrument failures); rerun 41/41 |
| T-34 | AC-505 | `--phase spoof` | 10:12 | PASS | `evidence/reads/01/spoof.json` | 7/7 |
| T-35 | AC-507 | `--phase r016` | 10:13 | PASS | `evidence/reads/01/r016.json` | 6/6 |
| T-36 | AC-602 | `--phase nomut` | 10:15 | PASS | `evidence/admin/01/no_mutation.json` | 9/9; 9 tables unchanged |
| T-37 | AC-304, 403, 504 | `--phase counts` | 10:11 | PASS | `evidence/audit/01/dev_operation_counts.json` | 18/18 = derivation |
| T-38 | AC-601, 902, R-5 | label assertions inside `matrix` | 10:05 | PASS (as the plan defines: pre-known defect observed) | `evidence/browser/01/labels/*` | → F-01, AC-601 ADJUDICATE |
| T-39 | KIP-1, AC-503 | `--phase authwalk` (rerun with UI logout, HC-5) | 10:16, 10:23 | PARTIAL: 12 PASS / 2 FAIL | `evidence/browser/01/auth_walk.json` | cross-tab sign-out not propagated → F-06 |
| T-40 | AC-503, SR-4 | `--phase responsive` (14 viewport×theme cells; OWNER3 rerun after HC-6) | 10:17, 10:25 | PASS | `evidence/browser/01/{responsive.json,responsive_run2_owner3.json,responsive/}` | all `scrollWidth ≤ width`; themes verified on `html.dark`; keyboard order follows DOM (pager before tabs) |
| T-41 | AC-506 (local) | curl against `:3138` | 09:51 | PASS | `evidence/reads/01/routes.txt` | `/moose-portal` 404, `/signup`/`/register` 404, `/auth` 200 |
| §3 mock pass | AC-501, AC-205 | stop `:3138` → mock build → serve → `--phase mockmode` → stop | 10:25 | PASS | `evidence/browser/01/mock_mode/*` | the helper's 2-minute audit window overlapped the responsive rerun (29 rows); the windowed query (0 rows) and the HAR (0 RPC) prove the kill switch (HC-10) |
| T-50 | AC-901, 902, 903 | read + pattern scan | 09:37 | FAIL (expected, R-1) | `evidence/identity/02/records_check.md` | → F-03 |
| H-1 | Director smoke | — | — | DEFERRED (Director; not waived, not PASS) | `AC_EVIDENCE_MATRIX.md` note | |
| H-2 | CRV on STAGING | — | — | NOT RUN (Gate D) | — | |

Label mapping to governing vocabulary: none needed (PASS · FAIL · BLOCKED · NOT RUN · ADJUDICATE only; "PARTIAL" above is a row summary whose parts carry the five labels in the matrix).

## 3. Helper corrections
| # | Helper | Failed attempt preserved at | Correction | Verified how | Assertion weakened? (must be No) |
|---|---|---|---|---|---|
| HC-1 | `money-rules.mjs --scratch` | `evidence/seed/01/money_rules_250.json` (first run overwritten; the 130 `rule7 aac_date_used` failures are quoted in this report and in F-07 context) | DATE columns were compared as JS `Date` strings; now parsed as text (`pg.types.setTypeParser(1082)`) and sliced to the calendar date | rerun 250/0; poison → 1 failure; revert → 0 | No (rule added: `wac_date_used` now also checked) |
| HC-2 | T-13 poison SQL | `evidence/privacy/01/poison.json` (first attempt error 42703, preserved in the chain log) | poison used `date_of_birth`, not a `user_data` column; replaced by existing patient/contact columns | poisoned verify fails on the identity-scan assertion; clean control passes | No |
| HC-3 | `cast-matrix.mjs` T-14 | `evidence/audit/01/cast_matrix.log` (first run FAIL line) | counted every `auth.users` row; the disposable SCRATCH holds 5 pre-existing non-seed users and a BIM-002 user; check scoped to the 7 seeded cast emails (each once, no OPERATOR, no role key) and the others reported as context | rerun 172 PASS | No |
| HC-4 | `role-matrix.mjs` matrix | `evidence/browser/01/matrix_run2_all.json`, `shots/matrix_MEMBER_B1_FAIL_MEMBER_B1_filters.png`, `debug_pbm_MEMBER_B1.json` | `selectOption` fired a synthetic `change` on an already-selected store (a native select does not) which nulls the PBM options (F-05); helper now selects only when the value differs | rerun MEMBER_B1/UNRELATED 41/41 | No |
| HC-5 | `role-matrix.mjs` authwalk | `evidence/browser/01/authwalk_run1.log` (UI logout path not reached → API logout) | avatar menu located via `header [aria-haspopup=menu]` → `menuitem Logout` | rerun: UI logout true; cross-tab FAIL stands (F-06) | No |
| HC-6 | `role-matrix.mjs` responsive keyboard | `evidence/browser/01/responsive.json` (run 1 FAIL row) | expected order assumed tabs before pager; DOM/visual order is Store select → pager → tabs → sort buttons; check now asserts that order and reachability | rerun 16/16 | No (order still asserted) |
| HC-7 | `scratch-sql.mjs --continue-on-error` | `evidence/schema/01/one_admin.json` (first run: 25P02 after the first expected 23505) | per-statement SAVEPOINT/ROLLBACK TO | rerun shows 23505, 23505, member insert OK, rolled back | No |
| HC-8 | `dev-apply-check.mjs` | `evidence/apply/01/t30_t31_run.log` (first runs) | `json_agg` text wraps lines → join before parse; `roles` array normalisation (`{a}` vs JSON array) | catalog projection equality PASS | No |
| HC-9 | `dev-apply-check.mjs` / `ro-sql.sh` | same | privilege-word literals in the grants query were refused by the ro-sql statement filter; query rewritten over `information_schema.role_table_grants`; filter tightened (data-modifying CTEs refused) | happy path, UPDATE and CTE refusals, SQL-fence attack all recorded | No |
| HC-10 | `role-matrix.mjs` mockmode | `evidence/browser/01/mock_mode/mockmode.json` (5th check FAIL) | the "last 2 minutes" audit window overlapped the responsive rerun; proof taken from the run-window query (0 rows) and the HAR (0 RPC) — `audit_window_check.txt`, `har_rpc_check.json` | both 0 | No |
| HC-11 | `qa-env.mjs` / `ro-sql.sh` | — (see F-04) | `.env.qa.local` values are written as `KEY='value'  # <- SOURCE`; parsers now honour the quotes/comment | loader lengths/refs OK; ro-sql happy path | No |
| HC-12 | `privacy-scan.mjs` | `evidence/privacy/01/evidence_scan.json` (earlier FAIL runs) | env-assignment pattern required a credential-shaped value (a bare public project ref is not a value); self-source excluded; fixture updated | fixture 6/6, control 0, evidence/AUTOMATION/package 0 hits | No |

## 4. Stops
| Stop ID | Phase / time | Identity | Affected checks | Evidence | Owner | Required resolution | Safe resume point | Resolved? |
|---|---|---|---|---|---|---|---|---|
| none | — | — | — | — | — | — | — | — |

No §5 stop condition fired. The Executor's credential-handling incident (two DB connection strings echoed into the Claude Code tool output / session transcript while debugging the env-file format; nothing written to any QAM file) is recorded as **F-04** with a rotation recommendation; it is not a plan stop and did not halt the campaign.

## 5. Human checks and Director touches (declared; counted)
| # | Purpose | Declared in plan? | When requested | Count |
|---|---|---|---|---|
| 1 | Director eyes-on CRV walk on STAGING (spec §10) | yes | not yet (Gate D) | 0 |
| 2 | Tony's manual app smoke (H-1) | yes (DEFERRED, not waived, not PASS) | — | 0 |

Actual sign-in counts per role (real `/auth` form logins on `:3138` against Dev v1, plus SCRATCH logins inside `cast-matrix.mjs`): DEV — OWNER3 26, MEMBER_B1 9, UNRELATED 4, MEMBER_B2B3 2, OWNER1 1, ADMIN_B2 1, ADMIN_B3 1 (**44** sessions; the plan estimated ≤ 28 — the overrun comes from phase reruns after helper corrections) — `evidence/browser/01/signins.json`. DEV `read_page` rows added by QA: 337 → see `evidence/audit/01/dev_operation_counts.json` and the attribution query (all OWNER3/MEMBER_B1/UNRELATED/MEMBER_B2B3 rows carry the acting uid, business id and `context.fn`). DEV business tables unchanged (T-36 hashes; HAR 0 table POSTs). SCRATCH: destroyed and reseeded as planned (final state: `audit:prove` seed in place).

## 6. Remaining untested areas
| AC / area | Reason | Owner |
|---|---|---|
| AC-701, AC-702, AC-703; AC-506 STAGING half | no deployment; Gate D is after Gate Q | Director |
| AC-404 SCRATCH live-signup half | SCRATCH signup posture UNKNOWN (§3); no attempt on any target | Director (state OFF, then QA attempts a rejected signup on SCRATCH) |
| AC-401 restore clause | ACCEPTED LIMITATION (C-02) | Director / JARVIS (Phase 8) |
| AC-403 "direct SELECT denial with authenticated tokens" **on DEV** | proven with real tokens on SCRATCH (T-17) against a catalog projection identical to DEV (T-30); the bound T-30/T-37 steps include no DEV token probe | QA Lead (accept or request a bounded DEV probe) |
| H-1 manual smoke, H-2 CRV | deferred / Gate D | Director |
| AC-901/902/903 PASS | records unfilled (F-03) | Cody / Director |

## 7. Final identities and inventory
| Field | Value |
|---|---|
| HEAD at end | `4d64504e85c56f1c987a703dd94575f489cb99ce` (unchanged; no Git mutation by QA) |
| `git status --porcelain` at end (only QA lane dirty) | all dirty paths under `agent_docs/`; product paths 0 — `evidence/identity/02/git_status_porcelain_q2_end.txt` (taken before packaging; the package files add `QAM/HANDOFFS/*Q2*`) |
| Final changed-file inventory (QA lane) | `QAM/QAM_EXECUTION_REPORT.md`, `QAM/AC_EVIDENCE_MATRIX.md`, `QAM/FINDINGS.md` (§1, §3.1), `QAM/QAM_PREFLIGHT.md` (Result/Evidence cells only), `QAM/QAM_STATE.md` (Executor entries), `QAM/AUTOMATION/{README.md,qa-env.mjs,qa-shim.mjs,ro-sql.sh,scratch-sql.mjs,launch-dev-real.mjs,derive.mjs,money-rules.mjs,seed-hash.mjs,cast-matrix.mjs,t21-trigger.mjs,t11_catalog.sql,dev-apply-check.mjs,role-matrix.mjs,debug-pbm-options.mjs,privacy-scan.mjs,inventory.mjs,build-package.mjs}`, `QAM/evidence/**` (lanes identity/02, derivations/01, board/01, schema/01, seed/01, audit/01, apply/01, reads/01, admin/01, browser/01, deploy/01, regression/01, privacy/01, INVENTORY.md), `QAM/HANDOFFS/{REVIEW_START_HERE_Q2_01.md,FILE_INDEX_Q2_01.json,APBM-003-CYBER-PHARMA_Q2_REVIEW_01.zip,README.md}`, `agent_docs/SESSIONS/session_2026-11-07.md`, `agent_docs/RESPONSES/response_2026-11-09_*_apbm003-qam-q2-execution.md` |
| Evidence inventory | `evidence/INVENTORY.md` (353 files; privacy scan 0 hits) |
| Package | `HANDOFFS/APBM-003-CYBER-PHARMA_Q2_REVIEW_01.zip` — SHA-256 recorded **outside** this report (`HANDOFFS/README.md` external receipt and the subsequent live `QAM_STATE.md` entry) |

## 8. Metrics (§17)
| Measure | Value |
|---|---|
| Preparation (Architect) | NOT RECORDED (not the Executor's measure) |
| Q1 · Review/wait · Q2 execution · Packaging · Repair · Cleanup | Q1 2026-11-07 14:36–15:05 (+ Q1b 16:05–16:54) · wait 2026-11-07 17:03 → 2026-11-09 09:15 · Q2 execution 09:15–10:45 (≈ 1 h 30 min) · packaging 10:45–11:00 · repair — · cleanup pending (QA Lead) |
| Director touches by purpose · helper corrections · product repairs · stops · retries · skipped checks · remaining gaps | Director touches 0 (H-1 deferred) · helper corrections 12 (HC-1…HC-12; all failed attempts preserved; no assertion weakened) · product repairs 0 · stops 0 · retries: phases rerun after helper corrections — T-13, T-15, T-17 group, T-33 (2 identities), T-39, T-40 (OWNER3) · skipped checks 0 (AC-404 SCRATCH half BLOCKED by release; AC-7xx NOT RUN by scope) · remaining gaps §6 |

## 9. Summary for the QA Lead (no verdict)
Totals by label (44 ACs): **PASS 35 · FAIL 3 (AC-901/902/903, records) · BLOCKED 1 (AC-404 SCRATCH half) · NOT RUN 3 (AC-701/702/703) · ADJUDICATE 2 (AC-401 restore clause per C-02; AC-601 truthful-display defect F-01)**. Findings by proposed class: `FINDINGS.md` §1 — F-01 contract/scope gap (R-5 demo labels over live data), F-02 proven pre-existing defect → follow-up (TRUNCATE/REFERENCES/TRIGGER grants to `anon`/`authenticated`; `authenticated` can TRUNCATE `user_data` at SQL level), F-03 acceptance failure (records), F-04 observation (Executor credential-handling incident; rotate the two DB passwords), F-05 observation (same-store `selectStore` nulls options), F-06 proven pre-existing defect → follow-up (cross-tab sign-out not propagated), F-07 observation (plan-text corrections), F-08 observation (AC-404 SCRATCH half blocked). Recommendation (supporting evidence only): the product behaviour the module set out to deliver — owner reach, audited closure of every claim read on both layers, exact cast/seed, scoped admin reads, truthful fetch states, no real-mode mutation — held under independent re-derivation on SCRATCH, DEV (read-only) and the real app; the open items are the inherited admin demo labels (F-01), the unfilled handoff records (F-03), the Director's SCRATCH signup posture (AC-404) and two pre-existing hardening items (F-02, F-06). Decision requested: adjudicate `FINDINGS.md` and `AC_EVIDENCE_MATRIX.md`.
